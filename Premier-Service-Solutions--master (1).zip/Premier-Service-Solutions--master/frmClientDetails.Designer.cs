﻿namespace Premier_Service_Solutions
{
    partial class frmClientDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNewClientDetails = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtbxClientID = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblCellNumber = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblContract = new System.Windows.Forms.Label();
            this.lblClientType = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbxClientType = new System.Windows.Forms.ComboBox();
            this.cmbxContract = new System.Windows.Forms.ComboBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.txtbxCallDurationNewClient = new System.Windows.Forms.TextBox();
            this.lblCallDurationClientDetails = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnNewClientDetails
            // 
            this.btnNewClientDetails.AutoSize = true;
            this.btnNewClientDetails.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnNewClientDetails.Location = new System.Drawing.Point(293, 12);
            this.btnNewClientDetails.Name = "btnNewClientDetails";
            this.btnNewClientDetails.Size = new System.Drawing.Size(253, 37);
            this.btnNewClientDetails.TabIndex = 0;
            this.btnNewClientDetails.Text = "New Client Details";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
<<<<<<< HEAD
            this.lblName.Location = new System.Drawing.Point(303, 142);
=======
            this.lblName.Location = new System.Drawing.Point(305, 189);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(39, 15);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name";
            // 
            // txtbxClientID
            // 
<<<<<<< HEAD
            this.txtbxNameNewClient.Location = new System.Drawing.Point(365, 139);
            this.txtbxNameNewClient.Name = "txtbxNameNewClient";
            this.txtbxNameNewClient.Size = new System.Drawing.Size(121, 23);
            this.txtbxNameNewClient.TabIndex = 2;
=======
            this.txtbxClientID.Location = new System.Drawing.Point(417, 185);
            this.txtbxClientID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtbxClientID.Name = "txtbxClientID";
            this.txtbxClientID.Size = new System.Drawing.Size(138, 27);
            this.txtbxClientID.TabIndex = 2;
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            // 
            // textBox1
            // 
<<<<<<< HEAD
            this.txtbxAddressNewClient.Location = new System.Drawing.Point(365, 177);
            this.txtbxAddressNewClient.Name = "txtbxAddressNewClient";
            this.txtbxAddressNewClient.Size = new System.Drawing.Size(121, 23);
            this.txtbxAddressNewClient.TabIndex = 4;
=======
            this.textBox1.Location = new System.Drawing.Point(417, 236);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(138, 27);
            this.textBox1.TabIndex = 4;
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
<<<<<<< HEAD
            this.lblAddress.Location = new System.Drawing.Point(293, 180);
=======
            this.lblAddress.Location = new System.Drawing.Point(305, 240);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(49, 15);
            this.lblAddress.TabIndex = 3;
            this.lblAddress.Text = "Address";
            // 
            // textBox2
            // 
<<<<<<< HEAD
            this.txtbxCellNumberNewClient.Location = new System.Drawing.Point(365, 220);
            this.txtbxCellNumberNewClient.Name = "txtbxCellNumberNewClient";
            this.txtbxCellNumberNewClient.Size = new System.Drawing.Size(121, 23);
            this.txtbxCellNumberNewClient.TabIndex = 6;
=======
            this.textBox2.Location = new System.Drawing.Point(417, 293);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(138, 27);
            this.textBox2.TabIndex = 6;
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            // 
            // lblCellNumber
            // 
            this.lblCellNumber.AutoSize = true;
<<<<<<< HEAD
            this.lblCellNumber.Location = new System.Drawing.Point(271, 223);
=======
            this.lblCellNumber.Location = new System.Drawing.Point(305, 297);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.lblCellNumber.Name = "lblCellNumber";
            this.lblCellNumber.Size = new System.Drawing.Size(71, 15);
            this.lblCellNumber.TabIndex = 5;
            this.lblCellNumber.Text = "CellNumber";
            // 
            // textBox3
            // 
<<<<<<< HEAD
            this.txtbxEmailNewClient.Location = new System.Drawing.Point(365, 264);
            this.txtbxEmailNewClient.Name = "txtbxEmailNewClient";
            this.txtbxEmailNewClient.Size = new System.Drawing.Size(121, 23);
            this.txtbxEmailNewClient.TabIndex = 8;
=======
            this.textBox3.Location = new System.Drawing.Point(417, 352);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(138, 27);
            this.textBox3.TabIndex = 8;
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
<<<<<<< HEAD
            this.lblEmail.Location = new System.Drawing.Point(306, 267);
=======
            this.lblEmail.Location = new System.Drawing.Point(305, 356);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(36, 15);
            this.lblEmail.TabIndex = 7;
            this.lblEmail.Text = "Email";
            // 
            // lblContract
            // 
            this.lblContract.AutoSize = true;
<<<<<<< HEAD
            this.lblContract.Location = new System.Drawing.Point(289, 308);
=======
            this.lblContract.Location = new System.Drawing.Point(305, 407);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.lblContract.Name = "lblContract";
            this.lblContract.Size = new System.Drawing.Size(53, 15);
            this.lblContract.TabIndex = 9;
            this.lblContract.Text = "Contract";
            // 
            // lblClientType
            // 
            this.lblClientType.AutoSize = true;
<<<<<<< HEAD
            this.lblClientType.Location = new System.Drawing.Point(277, 70);
=======
            this.lblClientType.Location = new System.Drawing.Point(305, 100);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.lblClientType.Name = "lblClientType";
            this.lblClientType.Size = new System.Drawing.Size(65, 15);
            this.lblClientType.TabIndex = 11;
            this.lblClientType.Text = "Client Type";
            // 
            // textBox7
            // 
<<<<<<< HEAD
            this.txtbxClientIDNewClient.Location = new System.Drawing.Point(365, 101);
            this.txtbxClientIDNewClient.Name = "txtbxClientIDNewClient";
            this.txtbxClientIDNewClient.Size = new System.Drawing.Size(121, 23);
            this.txtbxClientIDNewClient.TabIndex = 16;
=======
            this.textBox7.Location = new System.Drawing.Point(417, 135);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(138, 27);
            this.textBox7.TabIndex = 16;
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            // 
            // label7
            // 
            this.label7.AutoSize = true;
<<<<<<< HEAD
            this.label7.Location = new System.Drawing.Point(293, 104);
=======
            this.label7.Location = new System.Drawing.Point(305, 139);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "ClientID";
            // 
            // cmbxClientType
            // 
<<<<<<< HEAD
            this.cmbxClientTypeNewClient.FormattingEnabled = true;
            this.cmbxClientTypeNewClient.Location = new System.Drawing.Point(365, 67);
            this.cmbxClientTypeNewClient.Name = "cmbxClientTypeNewClient";
            this.cmbxClientTypeNewClient.Size = new System.Drawing.Size(121, 23);
            this.cmbxClientTypeNewClient.TabIndex = 17;
=======
            this.cmbxClientType.FormattingEnabled = true;
            this.cmbxClientType.Location = new System.Drawing.Point(417, 89);
            this.cmbxClientType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbxClientType.Name = "cmbxClientType";
            this.cmbxClientType.Size = new System.Drawing.Size(138, 28);
            this.cmbxClientType.TabIndex = 17;
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            // 
            // cmbxContract
            // 
<<<<<<< HEAD
            this.cmbxContractNewClient.FormattingEnabled = true;
            this.cmbxContractNewClient.Location = new System.Drawing.Point(365, 305);
            this.cmbxContractNewClient.Name = "cmbxContractNewClient";
            this.cmbxContractNewClient.Size = new System.Drawing.Size(121, 23);
            this.cmbxContractNewClient.TabIndex = 18;
=======
            this.cmbxContract.FormattingEnabled = true;
            this.cmbxContract.Location = new System.Drawing.Point(417, 407);
            this.cmbxContract.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbxContract.Name = "cmbxContract";
            this.cmbxContract.Size = new System.Drawing.Size(138, 28);
            this.cmbxContract.TabIndex = 18;
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(324, 373);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 19;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(420, 373);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 20;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // txtbxCallDurationNewClient
            // 
            this.txtbxCallDurationNewClient.Location = new System.Drawing.Point(762, 553);
            this.txtbxCallDurationNewClient.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtbxCallDurationNewClient.Name = "txtbxCallDurationNewClient";
<<<<<<< HEAD
            this.txtbxCallDurationNewClient.Size = new System.Drawing.Size(138, 23);
=======
            this.txtbxCallDurationNewClient.Size = new System.Drawing.Size(138, 27);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.txtbxCallDurationNewClient.TabIndex = 22;
            // 
            // lblCallDurationClientDetails
            // 
            this.lblCallDurationClientDetails.AutoSize = true;
            this.lblCallDurationClientDetails.Location = new System.Drawing.Point(665, 557);
            this.lblCallDurationClientDetails.Name = "lblCallDurationClientDetails";
            this.lblCallDurationClientDetails.Size = new System.Drawing.Size(79, 15);
            this.lblCallDurationClientDetails.TabIndex = 21;
            this.lblCallDurationClientDetails.Text = "Call Duration ";
            // 
            // frmClientDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
<<<<<<< HEAD
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn);
=======
            this.ClientSize = new System.Drawing.Size(914, 600);
>>>>>>> parent of 0d3feb7 (Merge branch 'master' into Andre_Johan_2)
            this.Controls.Add(this.txtbxCallDurationNewClient);
            this.Controls.Add(this.lblCallDurationClientDetails);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.cmbxContract);
            this.Controls.Add(this.cmbxClientType);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblClientType);
            this.Controls.Add(this.lblContract);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lblCellNumber);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtbxClientID);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnNewClientDetails);
            this.Name = "frmClientDetails";
            this.Text = "frmClientDetails";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label btnNewClientDetails;
        private Label lblName;
        private TextBox txtbxClientID;
        private TextBox textBox1;
        private Label lblAddress;
        private TextBox textBox2;
        private Label lblCellNumber;
        private TextBox textBox3;
        private Label lblEmail;
        private Label lblContract;
        private Label lblClientType;
        private TextBox textBox7;
        private Label label7;
        private ComboBox cmbxClientType;
        private ComboBox cmbxContract;
        private Button btnClear;
        private Button btnRegister;
        private TextBox txtbxCallDurationNewClient;
        private Label lblCallDurationClientDetails;
    }
}